# 🎰 DuziaAI Android App - Guia Completo

## 📋 O que este projeto faz
App Android que abre seu Streamlit DuziaAI V10.9 em uma WebView nativa,
com splash screen, pull-to-refresh e detecção de modo offline.

---

## ⚙️ PASSO 1 — Colocar sua URL

Abra o arquivo:
```
app/src/main/java/com/duziaai/app/MainActivity.java
```

Localize a linha:
```java
private static final String STREAMLIT_URL = "https://SUA-URL-AQUI.streamlit.app";
```

Substitua pela URL real do seu app, por exemplo:
```java
private static final String STREAMLIT_URL = "https://duziaai.streamlit.app";
```

---

## 🛠️ PASSO 2 — Abrir no Android Studio

1. Baixe e instale o **Android Studio** (gratuito):
   https://developer.android.com/studio

2. Abra o Android Studio → **"Open"** → selecione a pasta `DuziaAI_Android`

3. Aguarde o Gradle sincronizar (barra de progresso na parte inferior)

---

## 📱 PASSO 3 — Gerar o APK

### Opção A — Emulador (testar sem celular)
- Clique no ícone ▶️ Play no topo do Android Studio
- O emulador será aberto automaticamente

### Opção B — Celular físico
1. No celular: **Configurações → Sobre o telefone → Número de compilação** (toque 7x)
2. Ative **Opções do desenvolvedor → Depuração USB**
3. Conecte o celular via USB
4. No Android Studio, selecione seu celular na barra de dispositivos e clique ▶️

### Opção C — Gerar APK para distribuir
```
Build → Build Bundle(s)/APK(s) → Build APK(s)
```
O arquivo `.apk` ficará em:
```
app/build/outputs/apk/debug/app-debug.apk
```

---

## 📦 Estrutura do Projeto
```
DuziaAI_Android/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml        ← Permissões e configurações
│   │   ├── java/com/duziaai/app/
│   │   │   ├── MainActivity.java      ← ⚙️ COLOQUE SUA URL AQUI
│   │   │   └── SplashActivity.java    ← Tela de abertura
│   │   └── res/
│   │       ├── layout/
│   │       │   ├── activity_main.xml  ← Layout WebView
│   │       │   └── activity_splash.xml← Layout Splash
│   │       └── values/
│   │           ├── strings.xml
│   │           ├── styles.xml
│   │           └── colors.xml
│   └── build.gradle                   ← Dependências
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## ✅ Funcionalidades do App

| Recurso | Descrição |
|---------|-----------|
| 🌐 WebView | Abre o Streamlit em tela cheia |
| 🔄 Pull-to-refresh | Puxe para baixo para recarregar |
| 📡 Detecção offline | Mostra tela de erro sem internet |
| ⬅️ Botão voltar | Navega no histórico do WebView |
| 🌑 Tema escuro | Combina com o visual do DuziaAI |
| 📲 Splash screen | Tela de abertura com logo |
| 🔔 Compatível com Telegram | Notificações funcionam normalmente |

---

## 🔧 Requisitos Mínimos

- Android 5.0+ (API 21)
- Conexão com a internet
- Android Studio Arctic Fox ou superior

---

## ❓ Problemas comuns

**Gradle não sincroniza:**
→ File → Invalidate Caches → Restart

**App abre tela branca:**
→ Verifique se a URL do Streamlit está correta e acessível

**WebView não carrega JavaScript:**
→ Já está habilitado no código (`setJavaScriptEnabled(true)`)

---

## 📞 Dica Extra — Ícone personalizado
Para trocar o ícone, substitua os arquivos em:
```
app/src/main/res/mipmap-hdpi/
```
Use imagens PNG de 72x72px (hdpi), 48x48px (mdpi), 96x96px (xhdpi).
